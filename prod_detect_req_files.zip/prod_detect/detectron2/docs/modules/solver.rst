detectron2.solver 
=========================

.. automodule:: detectron2.solver
    :members:
    :undoc-members:
    :show-inheritance:
